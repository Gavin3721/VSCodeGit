/**
 * Created by Administrator on 2020/8/9 0009.
 */
var  newMedicine=[
    {
        saleId:'1111',//订单编号
        date:'2020-08-01',//出库时间
        name:'西瓜霜',
        id:'011',     //编号
        saleSi:'1',      //出库数量
        sale:'9',     //售价
        total:'9'      //总价
    },
    {
        saleId:'2222',//订单编号
        date:'2020-08-02',//出库时间
        name:'金嗓子喉片',
        id:'022',     //编号
        saleSi:'1',      //出库数量
        sale:'9',
        total:'9'
    },
    {
        saleId:'3333',//订单编号
        date:'2020-08-03',//出库时间
        name:'999感冒灵',
        id:'033',     //编号
        saleSi:'1',      //出库数量
        sale:'18',
        total:'18'
    },
    {
        saleId:'4444',//订单编号
        date:'2020-08-04',//出库时间
        name:'西瓜霜',
        id:'011',     //编号
        saleSi:'1',      //出库数量
        sale:'9',
        total:'9'
    },
    {
        saleId:'5555',//订单编号
        date:'2019-08-05',//出库时间
        name:'999感冒灵',
        id:'033',     //编号
        saleSi:'1',      //出库数量
        sale:'18',
        total:'18'

    },
    {
        saleId:'6666',//订单编号
        date:'2020-08-06',//出库时间
        name:'西瓜霜',
        id:'011',     //编号
        saleSi:'1',      //出库数量
        sale:'9',
        total:'9'
    },
    {
        saleId:'5555',//订单编号
        date:'2020-08-07',//出库时间
        name:'维C银翘片',
        id:'066',     //编号
        saleSi:'1',      //出库数量
        sale:'13',
        total:'13'
    },
    {
        saleId:'3333',//订单编号
        date:'2020-08-08',//出库时间
        name:'三九胃泰',
        id:'044',     //编号
        saleSi:'1',      //出库数量
        sale:'26',
        total:'26'
    }
];