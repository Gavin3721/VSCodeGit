
    var keShi=[
        {
           id: '1',
           km:'内科',
            sx:'nk',
            bz:'one',
            time:'a',
            name:'张一'
        },
        {
            id: '2',
            km:'外科',
            sx:'nk',
            bz:'two',
            time:'b',
            name:'张二'
        },
        {
            id: '3',
            km:'神经内科',
            sx:'nk',
            bz:'three',
            time:'c',
            name:'张三'
        },
        {
            id: '4',
            km:'儿科',
            sx:'nk',
            bz:'four',
            time:'d',
            name:'张四'
        },
        {
            id: '5',
            km:'内分泌科',
            sx:'nk',
            bz:'five',
            time:'e',
            name:'张五'
        },
        {
            id: '6',
            km:'泌尿科',
            sx:'nk',
            bz:'six',
            time:'f',
            name:'张六'
        },
        {
            id: '7',
            km:'妇科',
            sx:'nk',
            bz:'seven',
            time:'g',
            name:'张七'
        },
        {
            id: '8',
            km:'口腔科',
            sx:'nk',
            bz:'eight',
            time:'h',
            name:'张八'
        },
        {
            id: '9',
            km:'眼科',
            sx:'nk',
            bz:'nine',
            time:'i',
            name:'张九'
        },
        {
            id: '10',
            km:'耳鼻喉科',
            sx:'nk',
            bz:'ten',
            time:'j',
            name:'张十'
        }
    ];
    var yiShen=[
        {
            id:'111',
            name:'李一',
            ksId:'123',
            sex:'女',
            age:18,
            type:'实习医生',
            charge:'20'
        },
        {
            id:'111',
            name:'李二',
            ksId:'123',
            sex:'男',
            age:18,
            type:'普通医生',
            charge:'25'
        },
        {
            id:'111',
            name:'李三',
            ksId:'123',
            sex:'女',
            age:18,
            type:'专家医生',
            charge:'30'
        }
    ];