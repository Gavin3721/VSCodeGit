/**
 * Created by Administrator on 2020/8/8 0008.
 */
var guaHao = [
    {
        id: '1',
        saleId:'1111',
        idCard: '513721188511293399',
        name: '猪八戒',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id:'2',
        saleId:'1111',
        idCard: '513721188111293399',
        name: '孙悟空',
        age: '15',
        hun: '是',
        sex: '男',
        blood: 'A型'
    },
    {
        id: '3',
        saleId:'1111',
        idCard: '513721188211293399',
        name: "唐僧",
        age: '15',
        hun: '是',
        pingying: 'xxx',
        sex: '男',
        blood: 'A型'
    },
    {
        id: '4',
        saleId:'1111',
        idCard: '513721188311293399',
        name: '沙和尚',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '5',
        saleId:'1111',
        idCard: '513721188411293399',
        name: '兰馨',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '6',
        saleId:'1111',
        idCard: '513721188611293399',
        name: '黄雪',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '7',
        saleId:'1111',
        idCard: '513721188711293399',
        name: '蔡徐坤',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '8',
        saleId:'1111',
        idCard: '513721188811293399',
        name: '李光洙',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '9',
        saleId:'1111',
        idCard: '513721188911293399',
        name: '嫦娥',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '10',
        saleId:'1111',
        idCard: '513721199011293399',
        name: '后裔',
        age: '15',
        hun: '是',
        sex: '男'
    }
];

var hzArr=[
    {
        id: '1',
        saleId:'1111',
        idCard: '513721188511293399',
        name: '猪八戒',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id:'2',
        saleId:'2222',
        idCard: '513721188111293399',
        name: '孙悟空',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '3',
        saleId:'3333',
        idCard: '513721188211293399',
        name: "唐僧",
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '4',
        saleId:'4444',
        idCard: '513721188311293399',
        name: '沙和尚',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '5',
        saleId:'5555',
        idCard: '513721188411293399',
        name: '兰馨',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '6',
        saleId:'6666',
        idCard: '513721188611293399',
        name: '黄雪',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '7',
        saleId:'7777',
        idCard: '513721188711293399',
        name: '蔡徐坤',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '8',
        saleId:'8888',
        idCard: '513721188811293399',
        name: '李光洙',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '9',
        saleId:'9999',
        idCard: '513721188911293399',
        name: '嫦娥',
        age: '15',
        hun: '是',
        sex: '男'
    },
    {
        id: '10',
        saleId:'1010',
        idCard: '513721199011293399',
        name: '后裔',
        age: '15',
        hun: '是',
        sex: '男'
    }
];

var patientArr=[{
    idCard:'1',
    saleId:'1111',
    patientKS:'打喷嚏，流鼻涕，咳嗽',
    doctorZD:'普通感冒',
    suggest:'多喝水',
    caseH:'无',
    allergyH:'无'
},
    {
        idCard:'2',
        saleId:'2222',
        patientKS:'嗓子不舒服',
        doctorZD:'普通感冒',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'3',
        saleId:'3333',
        patientKS:'肚子疼',
        doctorZD:'普通感冒',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'4',
        saleId:'4444',
        patientKS:'额头及身体发热',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'5',
        saleId:'5555',
        patientKS:'打喷嚏，流鼻涕，咳嗽',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'6',
        saleId:'6666',
        patientKS:'嗓子不舒服',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'7',
        saleId:'7777',
        patientKS:'肚子疼',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'8',
        saleId:'8888',
        patientKS:'额头及身体发热',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'9',
        saleId:'9999',
        patientKS:'打喷嚏，流鼻涕，咳嗽',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    },
    {
        idCard:'10',
        saleId:'1010',
        patientKS:'嗓子不舒服',
        doctorZD:'普通发烧',
        suggest:'多喝水',
        caseH:'无',
        allergyH:'无'
    }
];

var localhuanzhe=[];//本地数据
var localzhenduan=[];//本地数据
var pageData = [];
var btn1=document.getElementById('btn1');
var btn2=document.getElementById('btn2');
var tableBody = document.querySelector('#personInfo tbody');
var pageBox = document.querySelector('#pageBox');
/*var tableBody1 = document.querySelector('#personInfo1 tbody');
var pageBox1 = document.querySelector('#pageBox1');*/
initTable();
function initTable(){//进入页面的初始状态，初始化表格
    //默认获取第一页的数据
    if(localStorage.getItem('guahao')==null&&localStorage.getItem('zhenduan')==null){
        localhuanzhe.setItem
        localStorage.setItem('guahao',JSON.stringify(guaHao));//把初始的假数据存储
        // localhuanzhe=JSON.parse(localStorage.getItem('huanzhe'));
        localhuanzhe = JSON.parse(localStorage.getItem('guahao'));
        localStorage.setItem('zhenduan',JSON.stringify(patientArr));//把初始的假数据存储
        localzhenduan=JSON.parse(localStorage.getItem('zhenduan'));
    }else{
        localhuanzhe = JSON.parse(localStorage.getItem('guahao'));
        // localhuanzhe=JSON.parse(localStorage.getItem('huanzhe'));
        localzhenduan=JSON.parse(localStorage.getItem('zhenduan'));
    }
    getPageData(localhuanzhe,1,5);
    //console.log(localhuanzhe);
    //渲染页面数据
    render(pageData,1,5);
    //渲染分页
    getPage(localhuanzhe.length,5);
}
function render(pageData,pageIndex,numPerPage){
    var trData = '';
    for(var i =0;i<pageData.length;i++){
        trData += "<tr align='center'>" +
        "<td><input type='checkbox' class='inputs' data-index="+i+">"+"</td>" +
        "<td>"+pageData[i].id+"</td>" +
        // "<td>"+pageData[i].saleId+"</td>" +
        "<td>"+pageData[i].idCard+"</td>" +
        "<td>"+pageData[i].name+"</td>" +
        "<td>"+pageData[i].age+"</td>" +
        "<td>"+pageData[i].hun+"</td>" +
        "<td>"+pageData[i].sex+"</td>" +
        "<td>"+
        '<button type="button" data-index="'+((pageIndex-1)*numPerPage+i)+'" class="ckBtn btn btn-danger">查看<button>' +
        "</td>" +
        "<td>"+
        '<button type="button" data-index="'+((pageIndex-1)*numPerPage+i)+'" class="zdBtn btn btn-warning">诊断详情<button>' +
        "</td>" +
            /*"<td><button onclick='delAlert()' class='delBtn' data-index='"+i+"'>删除</button>" +
             "<button id='xgBtn' style='margin-left: 20px' data-index='"+i+"'>修改</button></td>" +*/
        "</tr>";
    }
    tableBody.innerHTML = trData;
}
function getPage(total,numPerPage){
    var pageNum = Math.ceil(total/numPerPage);
    var lis='';
    for(var i=1;i<=pageNum;i++){
        if(i == 1){
            lis += '<li class="active">'+i+'</li>'
        }else{
            lis += '<li>'+i+'</li>'
        }
    }
    pageBox.innerHTML = lis;
    /* console.log(pageNum);*/
}
function getPageData(arr,index,numPerPage){
    pageData = arr.slice((index-1)*numPerPage, index * numPerPage)
}

$(pageBox).on('click','li',function(){
    console.log($(this).index());
    getPageData(localhuanzhe,$(this).index()+1,5);
    //console.log(localhuanzhe)
    render(pageData,$(this).index()+1,5);
    $(this).addClass('active').siblings('li').removeClass('active');
});
//添加功能

//修改----的模态框
function delAlert(){
    fyAlert.alert({
        title: "患者信息",
        drag: true,
        shadowClose: false,
        content: '<form action="">' +
        '<p>患者编号：<input type="text" id="mod1"/></p>' +
        '<p>订单编号：<input type="text" id="mod2"/></p>' +
        '<p>身份证号：<input type="text" id="mod3"/></p>' +
        '<p style="text-indent: 2em">姓名：<input type="text" id="mod4"/></p>' +
        '<p style="text-indent: 2em">年龄：<input type="text" id="mod5"/></p>' +
        '<p style="text-indent: 2em">婚否：<input type="text" id="mod6"/></p>' +
        '<p style="text-indent: 2em">性别：<input type="text" id="mod7"/></p>' +
        '</form>',
        btns: {
            '确 定': function (obj) {
                mod();
                obj.destory();
            },
            '取 消': function (obj) {
                obj.destory();
            }
        }
    });
}
function zhenduan(){
    fyAlert.alert({
        title: "诊断详情",
        drag: true,
        shadowClose: false,
        content: '<form action="">' +
        '<p>患者编号：<input type="text" id="mod01"/></p>' +
        '<p>订单编号：<input type="text" id="mod02"/></p>' +
        '<p>患者口述：<input type="text" id="mod03"/></p>' +
        '<p>医生诊断：<input type="text" id="mod04"/></p>' +
        '<p>医生建议：<input type="text" id="mod05"/></p>' +
        '<p style="text-indent: 1em">病例史：<input type="text" id="mod06"/></p>' +
        '<p style="text-indent: 1em">过敏史：<input type="text" id="mod07"/></p>' +
        '</form>',
        btns: {
            '开 药': function (obj) {
                mod1();
                location.href='../doctor/chufangyaopin.html';
                obj.destory();
            },
            '取 消': function (obj) {
                obj.destory();
            }
        }
    });
}
//删除--的模态框

//查看
$("tbody").on("click",".ckBtn",function() {
    //console.log("点击了修改事件");
    delAlert();
    //要修改的数据显示在模态框内
    //console.log($(this).data("index"));//这里的this指向#modBtn,index代表当前按钮的下标
    $("#mod1").val(localhuanzhe[$(this).data("index")].id);
    $("#mod2").val(localhuanzhe[$(this).data("index")].saleId);
    $("#mod3").val(localhuanzhe[$(this).data("index")].idCard);
    $("#mod4").val(localhuanzhe[$(this).data("index")].name);
    $("#mod5").val(localhuanzhe[$(this).data("index")].age);
    $("#mod6").val(localhuanzhe[$(this).data("index")].hun);
    $("#mod7").val(localhuanzhe[$(this).data("index")].sex);

    newMod = $(this).data("index");
});

//确定修改的函数
function mod() {
    //console.log($('.xgBtn').data("index")) ;
    localhuanzhe[newMod].id = $("#mod1").val();
    localhuanzhe[newMod].saleId = $("#mod2").val();
    localhuanzhe[newMod].idCard = $("#mod3").val();
    localhuanzhe[newMod].name = $("#mod4").val();
    localhuanzhe[newMod].age = $("#mod5").val();
    localhuanzhe[newMod].hun = $("#mod6").val();
    localhuanzhe[newMod].sex = $("#mod7").val();
    localStorage.setItem('yaopin',JSON.stringify(localhuanzhe));
    initTable();

}

//诊断
$("tbody").on("click",".zdBtn",function() {
    //console.log("点击了修改事件");
    zhenduan();
    //要修改的数据显示在模态框内
    //console.log($(this).data("index"));//这里的this指向#modBtn,index代表当前按钮的下标
    $("#mod01").val(localzhenduan[$(this).data("index")].idCard);
    $("#mod02").val(localzhenduan[$(this).data("index")].saleId);
    $("#mod03").val(localzhenduan[$(this).data("index")].patientKS);
    $("#mod04").val(localzhenduan[$(this).data("index")].doctorZD);
    $("#mod05").val(localzhenduan[$(this).data("index")].suggest);
    $("#mod06").val(localzhenduan[$(this).data("index")].caseH);
    $("#mod07").val(localzhenduan[$(this).data("index")].allergyH);

    newMod1 = $(this).data("index");
});

//确定修改的函数
function mod1() {
    //console.log($('.xgBtn').data("index")) ;
    localzhenduan[newMod1].idCard = $("#mod01").val();
    localzhenduan[newMod1].saleId = $("#mod02").val();
    localzhenduan[newMod1].patientKS = $("#mod03").val();
    localzhenduan[newMod1].doctorZD = $("#mod04").val();
    localzhenduan[newMod1].suggest = $("#mod05").val();
    localzhenduan[newMod1].caseH = $("#mod06").val();
    localzhenduan[newMod1].allergyH = $("#mod07").val();
    localStorage.setItem('zhenduan',JSON.stringify(localzhenduan));
    initTable();

}
//---------------------------------------------------------------------------


