
//--------------这是公共的js文件，大家引用到自己的文件中，项目整合的时候用
var loginState = true;//登录状态，目前先写死，代表登录成功
var currentUser = {};//当前登录人信息

$(function () {

});

